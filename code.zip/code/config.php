<?php
     $conn = new mysqli('localhost','root','','cinema');
     mysqli_set_charset($conn,"utf8");
?>